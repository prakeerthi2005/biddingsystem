from django.shortcuts import render, redirect
from django.db.models import Max
from django.contrib import messages
from .models import ProductBid, UserBid, Product
from django.contrib.auth import login, logout, authenticate
from .forms import RegistrationForm

# Create your views here.
def active_bids(request):
    products = []
    if "search_text" in request.GET:
        print(request.GET["search_text"])
        product_bids = ProductBid.objects.filter(product__name__contains=request.GET["search_text"], is_open=True)
    else:
        product_bids = ProductBid.objects.filter(is_open=True)
    context = {"product_bids": product_bids}
    return render(request, "pages/products.html", context=context)

def product(request, product_id):
    if request.method == "POST":
        product_bid = ProductBid.objects.filter(product__id=product_id).first()
        if not product_bid.is_open:
            messages.error(request, "Bid closed")
            return redirect("active_bids")
        user_bids = UserBid.objects.filter(product_bid=product_bid)
        max_bid = -1
        if len(user_bids) == 0:
            max_bid = product_bid.base_price
        else:
            max_bid = UserBid.objects.filter(product_bid=product_bid).aggregate(max_bid=Max('bid_amount'))["max_bid"]
        bid_amount = float(request.POST["bid_amount"])
        if bid_amount > max_bid:
            user_bid = UserBid(user=request.user, bid_amount=bid_amount, product_bid=product_bid)
            user_bid.save()
            messages.success(request, "Successfully submitted the bid")
        else:
            messages.error(request, "Please enter a higher amount than the leading price to submit the bid")
    product_bid = ProductBid.objects.filter(product__id=product_id).first()
    user_bids = UserBid.objects.filter(product_bid=product_bid).order_by("-bid_amount")
    context = {"product_bid": product_bid, "user_bids": user_bids}
    return render(request, "pages/product.html", context=context)

def manage_products(request):
    product_bids = ProductBid.objects.filter(product__posted_by=request.user)
    context = {"product_bids": product_bids}
    return render(request, "pages/manage_products.html", context=context)

def toggle_bid(request, product_bid_id):
    product_bid = ProductBid.objects.get(id=product_bid_id)
    if product_bid.product.posted_by != request.user:
        return redirect("active_bids")
    product_bid.is_open = not product_bid.is_open
    product_bid.save()
    return redirect("active_bids")

def login_user(request):
    if request.user.is_authenticated:
        return redirect("active_bids")
    
    if request.method == "POST":
        username = request.POST["username"]
        password = request.POST["password"]

        user = authenticate(username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect("active_bids")
        else:
            messages.info(request, "Incorrect credentials")
    
    context = {}
    return render(request, "pages/login.html", context=context)

def register_user(request):
    if request.user.is_authenticated:
        return redirect("active_bids")
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)  
            return redirect('active_bids')
    else:
        form = RegistrationForm()
    return render(request, 'pages/register.html', {'form': form})

def logout_user(request):
    if not request.user.is_authenticated:
        return redirect("active_bids")

    messages.success(request, f'{request.user} has been succesfully logged out.')
    logout(request)
    return redirect('login')