from django.urls import path
from .views import active_bids, product, manage_products, toggle_bid, login_user, register_user, logout_user

urlpatterns = [
    path("", active_bids, name="active_bids"),
    path("product/<int:product_id>", product, name="product"),
    path("manage-products/", manage_products, name="manage_products"),
    path("toggle-bid/<int:product_bid_id>", toggle_bid, name="toggle_bid"),
    path("login/", login_user, name="login"),
    path("register/", register_user, name="register"),
    path("logout/", logout_user, name="logout")
]
