from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MinValueValidator

# Create your models here.
class Product(models.Model):
    posted_by = models.ForeignKey(to=User, on_delete=models.CASCADE)
    name = models.CharField(max_length=1000)
    description = models.TextField(blank=False, null=False)
    image = models.ImageField(blank=True, null=True)

    @property
    def image_url(self):
        return self.image.url if self.image else ''

    def __str__(self):
        return f'{self.name}_{self.posted_by.username}'

class ProductBid(models.Model):
    product = models.OneToOneField(to=Product, on_delete=models.CASCADE)
    base_price = models.FloatField(validators=[MinValueValidator(0.0)])
    interval = models.FloatField(validators=[MinValueValidator(0.0)])
    posted_at = models.DateField(auto_created=True)
    is_open = models.BooleanField(default=False)

    maximum_bid = models.ForeignKey(to="UserBid", on_delete=models.CASCADE, null=True, blank=True)

    def __str__(self):
        return f'{self.product.name}_{self.product.posted_by.username}'

class UserBid(models.Model):
    product_bid = models.ForeignKey(to=ProductBid, on_delete=models.CASCADE)
    user = models.ForeignKey(to=User, on_delete=models.CASCADE)
    bid_amount = models.FloatField(validators=[MinValueValidator(0.0)])
    time = models.DateTimeField(auto_now=True)

    def __str__(self):
        return str(self.id)